-- Drop the old check constraint and add a new one that includes "price_mismatch"
ALTER TABLE public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_status_check;

ALTER TABLE public.purchase_orders ADD CONSTRAINT purchase_orders_status_check 
CHECK (status IN ('pending', 'processed', 'converted', 'duplicate', 'price_mismatch', 'error'));