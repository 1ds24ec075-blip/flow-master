-- Create purchase_orders table to store extracted PO data
CREATE TABLE public.purchase_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  po_number TEXT,
  vendor_name TEXT,
  vendor_address TEXT,
  customer_name TEXT,
  customer_address TEXT,
  order_date DATE,
  delivery_date DATE,
  total_amount DECIMAL(12, 2),
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processed', 'converted')),
  raw_text TEXT,
  original_filename TEXT,
  email_subject TEXT,
  email_from TEXT,
  email_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create purchase_order_items table for line items
CREATE TABLE public.purchase_order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  purchase_order_id UUID NOT NULL REFERENCES public.purchase_orders(id) ON DELETE CASCADE,
  item_number INTEGER,
  description TEXT,
  quantity DECIMAL(10, 2),
  unit TEXT,
  unit_price DECIMAL(12, 2),
  total_price DECIMAL(12, 2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS but allow public access for now (no auth)
ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchase_order_items ENABLE ROW LEVEL SECURITY;

-- Public access policies (since no auth)
CREATE POLICY "Allow public read access on purchase_orders"
  ON public.purchase_orders FOR SELECT
  USING (true);

CREATE POLICY "Allow public insert access on purchase_orders"
  ON public.purchase_orders FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow public update access on purchase_orders"
  ON public.purchase_orders FOR UPDATE
  USING (true);

CREATE POLICY "Allow public delete access on purchase_orders"
  ON public.purchase_orders FOR DELETE
  USING (true);

CREATE POLICY "Allow public read access on purchase_order_items"
  ON public.purchase_order_items FOR SELECT
  USING (true);

CREATE POLICY "Allow public insert access on purchase_order_items"
  ON public.purchase_order_items FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow public delete access on purchase_order_items"
  ON public.purchase_order_items FOR DELETE
  USING (true);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger for updated_at
CREATE TRIGGER update_purchase_orders_updated_at
  BEFORE UPDATE ON public.purchase_orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();