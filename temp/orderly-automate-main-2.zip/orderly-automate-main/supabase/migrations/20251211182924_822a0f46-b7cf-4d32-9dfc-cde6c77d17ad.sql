-- Create price list table for master product prices
CREATE TABLE public.price_list (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sku TEXT NOT NULL UNIQUE,
  product_name TEXT,
  unit_price NUMERIC NOT NULL,
  currency TEXT DEFAULT 'INR',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.price_list ENABLE ROW LEVEL SECURITY;

-- Public access policies (no auth as per project constraints)
CREATE POLICY "Allow public read access on price_list" 
ON public.price_list FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access on price_list" 
ON public.price_list FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access on price_list" 
ON public.price_list FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete access on price_list" 
ON public.price_list FOR DELETE 
USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_price_list_updated_at
BEFORE UPDATE ON public.price_list
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add price mismatch details column to purchase_orders
ALTER TABLE public.purchase_orders 
ADD COLUMN price_mismatch_details JSONB;