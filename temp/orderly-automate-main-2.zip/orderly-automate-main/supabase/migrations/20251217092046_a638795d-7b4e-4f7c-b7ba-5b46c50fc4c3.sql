-- Create customer_master table
CREATE TABLE public.customer_master (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_name TEXT NOT NULL,
  gst_number TEXT,
  billing_address TEXT,
  shipping_address TEXT,
  payment_terms TEXT,
  currency TEXT DEFAULT 'INR',
  tally_ledger_name TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  email TEXT,
  phone TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.customer_master ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Allow public read access on customer_master" 
ON public.customer_master FOR SELECT USING (true);

CREATE POLICY "Allow public insert access on customer_master" 
ON public.customer_master FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public update access on customer_master" 
ON public.customer_master FOR UPDATE USING (true);

CREATE POLICY "Allow public delete access on customer_master" 
ON public.customer_master FOR DELETE USING (true);

-- Create trigger for updated_at
CREATE TRIGGER update_customer_master_updated_at
BEFORE UPDATE ON public.customer_master
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add customer_master reference columns to purchase_orders
ALTER TABLE public.purchase_orders 
ADD COLUMN customer_master_id UUID REFERENCES public.customer_master(id),
ADD COLUMN source_customer_master_id UUID,
ADD COLUMN populated_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN population_source TEXT,
ADD COLUMN gst_number TEXT,
ADD COLUMN billing_address TEXT,
ADD COLUMN shipping_address TEXT,
ADD COLUMN payment_terms TEXT,
ADD COLUMN tally_ledger_name TEXT,
ADD COLUMN customer_match_log JSONB;

-- Create index for faster lookups
CREATE INDEX idx_customer_master_name ON public.customer_master(customer_name);
CREATE INDEX idx_customer_master_gst ON public.customer_master(gst_number);
CREATE INDEX idx_purchase_orders_customer_master ON public.purchase_orders(customer_master_id);