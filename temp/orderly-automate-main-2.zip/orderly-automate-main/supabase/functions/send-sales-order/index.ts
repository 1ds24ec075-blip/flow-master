import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.2";
import { PDFDocument, rgb, StandardFonts } from "https://esm.sh/pdf-lib@1.17.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendSalesOrderRequest {
  orderId: string;
  recipientEmail?: string;
}

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const gmailUser = Deno.env.get("GMAIL_SMTP_USER");
    const gmailPassword = Deno.env.get("GMAIL_SMTP_PASSWORD");

    if (!gmailUser || !gmailPassword) {
      throw new Error("Gmail SMTP credentials not configured. Please set GMAIL_SMTP_USER and GMAIL_SMTP_PASSWORD.");
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { orderId, recipientEmail }: SendSalesOrderRequest = await req.json();

    if (!orderId) {
      return new Response(
        JSON.stringify({ error: "Order ID is required" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Fetch order data
    const { data: order, error: orderError } = await supabase
      .from("purchase_orders")
      .select("*")
      .eq("id", orderId)
      .single();

    if (orderError || !order) {
      console.error("Error fetching order:", orderError);
      return new Response(
        JSON.stringify({ error: "Order not found" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Fetch order items
    const { data: items, error: itemsError } = await supabase
      .from("purchase_order_items")
      .select("*")
      .eq("purchase_order_id", orderId)
      .order("item_number");

    if (itemsError) {
      console.error("Error fetching items:", itemsError);
    }

    const orderItems = items || [];
    
    // Determine recipient email - extract email from format like "Name <email@domain.com>"
    let toEmail = recipientEmail;
    if (toEmail) {
      const emailMatch = toEmail.match(/<([^>]+)>/);
      toEmail = emailMatch ? emailMatch[1] : toEmail;
    }
    if (!toEmail && order.email_from) {
      const emailMatch = order.email_from.match(/<([^>]+)>/);
      toEmail = emailMatch ? emailMatch[1] : order.email_from;
    }

    if (!toEmail) {
      return new Response(
        JSON.stringify({ error: "No recipient email available" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Sending sales order to: ${toEmail}`);

    // Generate PDF
    const pdfBytes = await generateSalesOrderPDF(order, orderItems);
    const pdfBase64 = btoa(String.fromCharCode(...new Uint8Array(pdfBytes)));

    const soNumber = `SO-${order.po_number?.replace(/[^0-9]/g, "") || Date.now()}`;

    // Send email using Gmail API via SMTP relay
    // Using raw SMTP protocol implementation
    const emailContent = createEmailWithAttachment(
      gmailUser,
      toEmail,
      `Sales Order ${soNumber} - Confirmation`,
      `Dear ${order.customer_name || "Customer"},

Please find attached the Sales Order ${soNumber} corresponding to your Purchase Order ${order.po_number || "N/A"}.

Order Details:
- PO Number: ${order.po_number || "N/A"}
- Order Date: ${order.order_date ? new Date(order.order_date).toLocaleDateString() : "N/A"}
- Total Amount: ${formatCurrency(order.total_amount || 0, order.currency || "USD")}

Thank you for your business!

Best regards,
Sales Team`,
      `${soNumber}.pdf`,
      pdfBase64
    );

    // Connect to Gmail SMTP and send
    await sendEmailViaSMTP(gmailUser, gmailPassword, toEmail, emailContent);

    console.log("Email sent successfully via Gmail SMTP");

    return new Response(
      JSON.stringify({ success: true, message: `Sales Order sent to ${toEmail}` }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in send-sales-order function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
});

function createEmailWithAttachment(
  from: string,
  to: string,
  subject: string,
  body: string,
  attachmentName: string,
  attachmentBase64: string
): string {
  const boundary = `boundary_${Date.now()}_${Math.random().toString(36).substr(2)}`;
  
  const email = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: ${subject}`,
    `MIME-Version: 1.0`,
    `Content-Type: multipart/mixed; boundary="${boundary}"`,
    ``,
    `--${boundary}`,
    `Content-Type: text/plain; charset="UTF-8"`,
    `Content-Transfer-Encoding: 7bit`,
    ``,
    body,
    ``,
    `--${boundary}`,
    `Content-Type: application/pdf; name="${attachmentName}"`,
    `Content-Disposition: attachment; filename="${attachmentName}"`,
    `Content-Transfer-Encoding: base64`,
    ``,
    attachmentBase64,
    ``,
    `--${boundary}--`,
  ].join("\r\n");

  return email;
}

async function sendEmailViaSMTP(user: string, password: string, to: string, emailContent: string): Promise<void> {
  // Connect to Gmail SMTP server
  const conn = await Deno.connect({ hostname: "smtp.gmail.com", port: 587 });
  
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  async function read(): Promise<string> {
    const buffer = new Uint8Array(4096);
    const n = await conn.read(buffer);
    if (n === null) throw new Error("Connection closed");
    return decoder.decode(buffer.subarray(0, n));
  }

  async function write(data: string): Promise<void> {
    await conn.write(encoder.encode(data + "\r\n"));
  }

  async function command(cmd: string, expectedCode: string): Promise<string> {
    await write(cmd);
    const response = await read();
    console.log(`SMTP: ${cmd.startsWith("AUTH") ? "AUTH ***" : cmd} -> ${response.substring(0, 50)}`);
    if (!response.startsWith(expectedCode)) {
      throw new Error(`SMTP Error: Expected ${expectedCode}, got: ${response}`);
    }
    return response;
  }

  try {
    // Read greeting
    const greeting = await read();
    console.log("SMTP Greeting:", greeting.substring(0, 50));

    // EHLO
    await command("EHLO localhost", "250");

    // STARTTLS
    await command("STARTTLS", "220");

    // Upgrade to TLS
    const tlsConn = await Deno.startTls(conn, { hostname: "smtp.gmail.com" });
    
    // Replace connection functions for TLS
    const tlsRead = async (): Promise<string> => {
      const buffer = new Uint8Array(4096);
      const n = await tlsConn.read(buffer);
      if (n === null) throw new Error("Connection closed");
      return decoder.decode(buffer.subarray(0, n));
    };

    const tlsWrite = async (data: string): Promise<void> => {
      await tlsConn.write(encoder.encode(data + "\r\n"));
    };

    const tlsCommand = async (cmd: string, expectedCode: string): Promise<string> => {
      await tlsWrite(cmd);
      const response = await tlsRead();
      console.log(`SMTP TLS: ${cmd.startsWith("AUTH") ? "AUTH ***" : cmd} -> ${response.substring(0, 50)}`);
      if (!response.startsWith(expectedCode)) {
        throw new Error(`SMTP Error: Expected ${expectedCode}, got: ${response}`);
      }
      return response;
    };

    // EHLO again after STARTTLS
    await tlsCommand("EHLO localhost", "250");

    // AUTH LOGIN
    await tlsWrite("AUTH LOGIN");
    let authResp = await tlsRead();
    console.log("AUTH LOGIN response:", authResp.substring(0, 20));
    
    // Send username (base64)
    await tlsWrite(btoa(user));
    authResp = await tlsRead();
    console.log("Username response:", authResp.substring(0, 20));
    
    // Send password (base64)
    await tlsWrite(btoa(password));
    authResp = await tlsRead();
    console.log("Password response:", authResp.substring(0, 20));
    
    if (!authResp.startsWith("235")) {
      throw new Error(`Authentication failed: ${authResp}`);
    }

    // MAIL FROM
    await tlsCommand(`MAIL FROM:<${user}>`, "250");

    // RCPT TO
    await tlsCommand(`RCPT TO:<${to}>`, "250");

    // DATA
    await tlsCommand("DATA", "354");

    // Send email content
    await tlsWrite(emailContent);
    await tlsCommand(".", "250");

    // QUIT
    await tlsWrite("QUIT");

    tlsConn.close();
  } catch (error) {
    conn.close();
    throw error;
  }
}

function formatCurrency(amount: number, currency: string): string {
  const currencySymbols: Record<string, string> = {
    INR: "Rs.",
    USD: "$",
    EUR: "EUR",
    GBP: "GBP",
  };
  
  const symbol = currencySymbols[currency?.toUpperCase()] || currency || "";
  const formattedNumber = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
  
  return `${symbol}${formattedNumber}`;
}

function formatDate(dateString: string | null): string {
  if (!dateString) return "N/A";
  return new Date(dateString).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

async function generateSalesOrderPDF(order: any, items: any[]): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([612, 792]);
  const { width, height } = page.getSize();
  
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  
  const soNumber = `SO-${order.po_number?.replace(/[^0-9]/g, "") || Date.now()}`;
  const margin = 50;
  let yPos = height - margin;

  page.drawText("YOUR COMPANY NAME", {
    x: margin,
    y: yPos,
    size: 18,
    font: boldFont,
    color: rgb(0.2, 0.4, 0.6),
  });
  yPos -= 20;

  page.drawText("123 Business Street, City, State 12345", {
    x: margin,
    y: yPos,
    size: 9,
    font: font,
    color: rgb(0.4, 0.4, 0.4),
  });
  yPos -= 12;

  page.drawText("Phone: (555) 123-4567 | Email: sales@company.com", {
    x: margin,
    y: yPos,
    size: 9,
    font: font,
    color: rgb(0.4, 0.4, 0.4),
  });

  page.drawText("SALES ORDER", {
    x: width - margin - 120,
    y: height - margin,
    size: 24,
    font: boldFont,
    color: rgb(0.2, 0.4, 0.6),
  });

  page.drawText(soNumber, {
    x: width - margin - 100,
    y: height - margin - 25,
    size: 12,
    font: font,
    color: rgb(0.3, 0.3, 0.3),
  });

  yPos -= 40;

  page.drawLine({
    start: { x: margin, y: yPos },
    end: { x: width - margin, y: yPos },
    thickness: 1,
    color: rgb(0.8, 0.8, 0.8),
  });

  yPos -= 30;

  page.drawText("Order Information", {
    x: margin,
    y: yPos,
    size: 11,
    font: boldFont,
    color: rgb(0.2, 0.2, 0.2),
  });
  yPos -= 18;

  const orderInfo = [
    ["PO Number:", order.po_number || "N/A"],
    ["Order Date:", formatDate(order.order_date)],
    ["Delivery Date:", formatDate(order.delivery_date)],
  ];

  for (const [label, value] of orderInfo) {
    page.drawText(label, { x: margin, y: yPos, size: 9, font: boldFont, color: rgb(0.3, 0.3, 0.3) });
    page.drawText(value, { x: margin + 80, y: yPos, size: 9, font: font, color: rgb(0.2, 0.2, 0.2) });
    yPos -= 14;
  }

  yPos -= 10;
  page.drawText("Bill To:", {
    x: margin,
    y: yPos,
    size: 11,
    font: boldFont,
    color: rgb(0.2, 0.2, 0.2),
  });
  yPos -= 16;

  page.drawText(order.customer_name || "N/A", {
    x: margin,
    y: yPos,
    size: 9,
    font: font,
    color: rgb(0.2, 0.2, 0.2),
  });
  yPos -= 12;

  if (order.customer_address) {
    const addressLines = order.customer_address.split("\n");
    for (const line of addressLines.slice(0, 3)) {
      page.drawText(line.trim(), {
        x: margin,
        y: yPos,
        size: 9,
        font: font,
        color: rgb(0.2, 0.2, 0.2),
      });
      yPos -= 12;
    }
  }

  yPos -= 20;

  const colX = [margin, margin + 40, margin + 260, margin + 310, margin + 370, margin + 440];

  page.drawRectangle({
    x: margin,
    y: yPos - 5,
    width: width - margin * 2,
    height: 20,
    color: rgb(0.2, 0.4, 0.6),
  });

  const headers = ["#", "Description", "Qty", "Unit", "Price", "Total"];
  headers.forEach((header, i) => {
    page.drawText(header, {
      x: colX[i] + 5,
      y: yPos,
      size: 9,
      font: boldFont,
      color: rgb(1, 1, 1),
    });
  });

  yPos -= 25;

  items.forEach((item, index) => {
    const rowData = [
      String(item.item_number || index + 1),
      (item.description || "").substring(0, 40),
      String(item.quantity || 0),
      item.unit || "-",
      formatCurrency(item.unit_price || 0, order.currency || "USD"),
      formatCurrency(item.total_price || 0, order.currency || "USD"),
    ];

    if (index % 2 === 0) {
      page.drawRectangle({
        x: margin,
        y: yPos - 5,
        width: width - margin * 2,
        height: 16,
        color: rgb(0.96, 0.96, 0.96),
      });
    }

    rowData.forEach((text, i) => {
      page.drawText(text, {
        x: colX[i] + 5,
        y: yPos,
        size: 8,
        font: font,
        color: rgb(0.2, 0.2, 0.2),
      });
    });

    yPos -= 18;
  });

  yPos -= 20;

  const subtotal = (order as any).subtotal || items.reduce((sum: number, item: any) => sum + (item.total_price || 0), 0);
  const taxAmount = (order as any).tax_amount || 0;
  const taxPercentage = (order as any).tax_percentage || (subtotal > 0 && taxAmount > 0 ? ((taxAmount / subtotal) * 100).toFixed(1) : 0);
  const discountAmount = (order as any).discount_amount || 0;
  const total = order.total_amount || (subtotal + taxAmount - discountAmount);

  const totalsX = width - margin - 150;
  
  page.drawText("Subtotal:", { x: totalsX, y: yPos, size: 9, font: font, color: rgb(0.3, 0.3, 0.3) });
  page.drawText(formatCurrency(subtotal, order.currency || "USD"), { x: totalsX + 80, y: yPos, size: 9, font: font, color: rgb(0.2, 0.2, 0.2) });
  yPos -= 14;

  if (taxAmount > 0) {
    const taxLabel = taxPercentage ? `Tax (${taxPercentage}%):` : "Tax:";
    page.drawText(taxLabel, { x: totalsX, y: yPos, size: 9, font: font, color: rgb(0.3, 0.3, 0.3) });
    page.drawText(formatCurrency(taxAmount, order.currency || "USD"), { x: totalsX + 80, y: yPos, size: 9, font: font, color: rgb(0.2, 0.2, 0.2) });
    yPos -= 14;
  }

  if (discountAmount > 0) {
    page.drawText("Discount:", { x: totalsX, y: yPos, size: 9, font: font, color: rgb(0.3, 0.3, 0.3) });
    page.drawText(`-${formatCurrency(discountAmount, order.currency || "USD")}`, { x: totalsX + 80, y: yPos, size: 9, font: font, color: rgb(0.2, 0.2, 0.2) });
    yPos -= 14;
  }

  page.drawLine({
    start: { x: totalsX, y: yPos + 5 },
    end: { x: width - margin, y: yPos + 5 },
    thickness: 1,
    color: rgb(0.2, 0.4, 0.6),
  });

  page.drawText("TOTAL:", { x: totalsX, y: yPos - 10, size: 11, font: boldFont, color: rgb(0.2, 0.4, 0.6) });
  page.drawText(formatCurrency(total, order.currency || "USD"), { x: totalsX + 80, y: yPos - 10, size: 11, font: boldFont, color: rgb(0.2, 0.4, 0.6) });

  page.drawText("Thank you for your business!", {
    x: margin,
    y: 60,
    size: 10,
    font: font,
    color: rgb(0.4, 0.4, 0.4),
  });

  return pdfDoc.save();
}
