import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY is not configured");
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    const { pdfBase64, filename, emailSubject, emailFrom, emailDate, extractOnly } = await req.json();

    if (!pdfBase64) {
      return new Response(
        JSON.stringify({ success: false, error: "No PDF data provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Processing PDF:", filename, extractOnly ? "(extract only mode)" : "");

    // Use Gemini with vision capabilities to extract text from PDF
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-pro",
        messages: [
          {
            role: "system",
            content: `You are an expert at extracting structured data from Purchase Order (PO) documents of various formats.

DOCUMENT STRUCTURE UNDERSTANDING:
Purchase Orders can have different layouts and terminology:
- "Vendor"/"Supplier"/"Seller"/"From" = The company SELLING goods (extract as vendor_name)
- "Ship To"/"Bill To"/"Customer"/"Buyer"/"Sold To" = The company BUYING goods (extract as customer_name)
- The company logo/header at TOP is usually the BUYER issuing the PO
- PO Number may appear as: "PO No", "Purchase Order #", "Order Number", "P.O. Number", etc.
- Dates may be: "PO Date", "Order Date", "Date", etc. in formats DD-MM-YYYY, MM/DD/YYYY, YYYY-MM-DD

TABLE EXTRACTION:
Line items may have columns like:
- S.No/Sr.No/Item#/Line = item_number
- Product Name/Description/Item/Particulars/Product Code = description
- Qty/Quantity/Units = quantity
- UOM/Unit/Units = unit (nos/pcs/kg/box/etc.)
- Rate/Price/Unit Price = unit_price (BEFORE tax)
- Tax/GST/VAT/Tax% = tax_rate
- Amount/Total/Line Total = total_price (may or may not include tax)
- HSN Code = for reference only, include in description if present

TOTALS SECTION:
Look for summary rows at bottom:
- "Subtotal"/"Sub Total"/"Total Before Tax" = subtotal
- "Tax"/"GST"/"CGST+SGST"/"IGST"/"VAT" = tax_amount
- "Discount"/"Less: Discount" = discount_amount  
- "Grand Total"/"Net Total"/"Amount Payable"/"Total" (the LAST/FINAL total) = total_amount

Extract and return as valid JSON:
{
  "po_number": "string or null",
  "vendor_name": "string or null - the supplier/seller company name",
  "vendor_address": "string or null - full address of vendor",
  "customer_name": "string or null - the buyer/ship-to company name", 
  "customer_address": "string or null - full address of customer",
  "order_date": "YYYY-MM-DD or null - convert any date format to this",
  "delivery_date": "YYYY-MM-DD or null",
  "subtotal": number or null,
  "tax_amount": number or null,
  "tax_percentage": number or null,
  "discount_amount": number or null,
  "total_amount": number or null - the FINAL GRAND TOTAL,
  "currency": "INR/USD/EUR/GBP - detect from ₹=INR, $=USD, €=EUR, £=GBP, or Indian context=INR",
  "items": [
    {
      "item_number": number,
      "description": "string - product name with any code/HSN for reference",
      "quantity": number,
      "unit": "string",
      "unit_price": number,
      "tax_rate": number or null,
      "total_price": number
    }
  ],
  "payment_terms": "string or null",
  "notes": "string or null",
  "raw_text": "full document text"
}

CRITICAL RULES:
1. For Indian documents (GSTIN, ₹, Indian addresses): Use currency "INR"
2. Convert ALL dates to YYYY-MM-DD format (e.g., 27-04-2024 → 2024-04-27)
3. total_amount MUST be the FINAL/GRAND total after all taxes and discounts
4. Parse numbers carefully - remove commas (12,600.00 → 12600.00)
5. Extract ALL line items from the table
6. Return ONLY valid JSON, no markdown or explanations`,
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Extract all purchase order details from this PDF document. Return only valid JSON.",
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:application/pdf;base64,${pdfBase64}`,
                },
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ success: false, error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ success: false, error: "Payment required. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw new Error(`AI extraction failed: ${response.status}`);
    }

    const aiResult = await response.json();
    const content = aiResult.choices?.[0]?.message?.content;
    
    console.log("AI Response:", content);

    // Parse the extracted data
    let extractedData;
    try {
      // Clean up the response - remove markdown code blocks if present
      let jsonStr = content.trim();
      if (jsonStr.startsWith("```json")) {
        jsonStr = jsonStr.slice(7);
      }
      if (jsonStr.startsWith("```")) {
        jsonStr = jsonStr.slice(3);
      }
      if (jsonStr.endsWith("```")) {
        jsonStr = jsonStr.slice(0, -3);
      }
      extractedData = JSON.parse(jsonStr.trim());
    } catch (parseError) {
      console.error("Failed to parse AI response:", parseError);
      extractedData = { raw_text: content, items: [] };
    }

    // If extractOnly mode, return the extracted data without saving to database
    if (extractOnly) {
      console.log("Extract only mode - returning extracted data without saving");
      return new Response(
        JSON.stringify({ 
          success: true, 
          extractOnly: true,
          extractedData 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check for duplicate PO: same PO number + same sender (company), regardless of time
    // Only flag as duplicate if the existing PO is not already a duplicate itself
    let existingPO = null;
    
    if (extractedData.po_number && emailFrom) {
      const { data: existingPOData } = await supabase
        .from("purchase_orders")
        .select("id, po_number, created_at, email_from, status")
        .eq("po_number", extractedData.po_number)
        .eq("email_from", emailFrom)
        .neq("status", "duplicate") // Don't match against other duplicates
        .limit(1)
        .maybeSingle();
      
      existingPO = existingPOData;
    }

    if (existingPO) {
      console.log("Duplicate PO detected - same PO number from same sender:", extractedData.po_number, "from:", emailFrom, "Original ID:", existingPO.id, "Original status:", existingPO.status);
      
      // Insert a record marked as duplicate for visibility in dashboard
      await supabase
        .from("purchase_orders")
        .insert({
          po_number: extractedData.po_number,
          vendor_name: extractedData.vendor_name,
          vendor_address: extractedData.vendor_address,
          customer_name: extractedData.customer_name,
          customer_address: extractedData.customer_address,
          order_date: extractedData.order_date,
          delivery_date: extractedData.delivery_date,
          total_amount: extractedData.total_amount,
          currency: extractedData.currency || "USD",
          status: "duplicate",
          raw_text: `DUPLICATE OF: ${existingPO.id} (status: ${existingPO.status})\n\n${extractedData.raw_text || ""}`,
          original_filename: filename,
          email_subject: emailSubject,
          email_from: emailFrom,
          email_date: emailDate,
        });

      return new Response(
        JSON.stringify({ 
          success: true, 
          isDuplicate: true,
          existingPurchaseOrderId: existingPO.id,
          existingStatus: existingPO.status,
          message: `Duplicate PO ${extractedData.po_number} detected - already processed at ${existingPO.created_at} with status "${existingPO.status}"`,
          extractedData
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ========== CUSTOMER MASTER MATCHING ==========
    console.log("Matching customer from PO:", extractedData.customer_name);
    
    let matchedCustomer = null;
    let customerMatchLog: any = {
      po_customer_name: extractedData.customer_name,
      po_customer_address: extractedData.customer_address,
      matched: false,
      match_method: null,
      mismatches: [],
    };

    if (extractedData.customer_name) {
      // Try to match by customer name (case-insensitive, partial match)
      const customerName = extractedData.customer_name.toUpperCase().trim();
      
      const { data: customers } = await supabase
        .from("customer_master")
        .select("*")
        .eq("is_active", true);

      if (customers && customers.length > 0) {
        for (const customer of customers) {
          const masterName = (customer.customer_name || "").toUpperCase().trim();
          
          // Exact match or partial match
          if (masterName === customerName || 
              masterName.includes(customerName) || 
              customerName.includes(masterName)) {
            matchedCustomer = customer;
            customerMatchLog.matched = true;
            customerMatchLog.match_method = "name_match";
            customerMatchLog.matched_customer_id = customer.id;
            customerMatchLog.matched_customer_name = customer.customer_name;
            console.log("Found customer match:", customer.customer_name);
            break;
          }
        }
      }

      // Log mismatches between PO data and Customer Master
      if (matchedCustomer) {
        if (extractedData.customer_name !== matchedCustomer.customer_name) {
          customerMatchLog.mismatches.push({
            field: "customer_name",
            po_value: extractedData.customer_name,
            master_value: matchedCustomer.customer_name,
          });
        }
        if (extractedData.customer_address && matchedCustomer.billing_address &&
            extractedData.customer_address !== matchedCustomer.billing_address) {
          customerMatchLog.mismatches.push({
            field: "address",
            po_value: extractedData.customer_address,
            master_value: matchedCustomer.billing_address,
          });
        }
      }
    }

    console.log("Customer match result:", JSON.stringify(customerMatchLog));

    // ========== VALIDATION RULES ==========
    let validationErrors: string[] = [];
    
    if (matchedCustomer) {
      // Block if customer is inactive (already filtered, but double-check)
      if (!matchedCustomer.is_active) {
        validationErrors.push("Customer is inactive in Customer Master");
      }
      
      // Block if GST number is missing in customer master
      if (!matchedCustomer.gst_number) {
        validationErrors.push("GST number is missing in Customer Master");
      }
    }

    // If validation fails, don't auto-convert
    const hasValidationErrors = validationErrors.length > 0;
    if (hasValidationErrors) {
      console.log("Validation errors:", validationErrors);
    }

    // Check prices against master price list
    let priceMismatches: any[] = [];
    const PRICE_TOLERANCE = 0.02; // 2% tolerance

    if (extractedData.items && extractedData.items.length > 0) {
      console.log("Checking prices for", extractedData.items.length, "items");
      
      // Get all price list items
      const { data: priceList } = await supabase
        .from("price_list")
        .select("sku, product_name, unit_price, currency");
      
      console.log("Price list items:", priceList?.length || 0);
      
      if (priceList && priceList.length > 0) {
        for (const item of extractedData.items) {
          const description = (item.description || "").toUpperCase().trim();
          
          for (const priceItem of priceList) {
            const sku = (priceItem.sku || "").toUpperCase().trim();
            const productName = (priceItem.product_name || "").toUpperCase().trim();
            
            // Match by: SKU in description, OR product name matches description
            const skuMatch = sku && description.includes(sku);
            const nameMatch = productName && (
              description.includes(productName) || 
              productName.includes(description) ||
              description === productName
            );
            
            if (skuMatch || nameMatch) {
              const expectedPrice = Number(priceItem.unit_price);
              const actualPrice = Number(item.unit_price);
              
              // Calculate variance percentage
              const variance = Math.abs(expectedPrice - actualPrice) / expectedPrice;
              
              console.log(`Found price match: "${item.description}" -> SKU: ${priceItem.sku}, Expected: ${expectedPrice}, Actual: ${actualPrice}, Variance: ${(variance * 100).toFixed(2)}%`);
              
              if (variance > PRICE_TOLERANCE) {
                priceMismatches.push({
                  sku: priceItem.sku,
                  product_name: priceItem.product_name,
                  item_description: item.description,
                  expected_price: expectedPrice,
                  actual_price: actualPrice,
                  variance_percent: (variance * 100).toFixed(2),
                  item_number: item.item_number
                });
                console.log(`PRICE MISMATCH for "${priceItem.product_name}": expected ${expectedPrice}, got ${actualPrice} (${(variance * 100).toFixed(2)}% variance)`);
              }
              break; // Found match, move to next item
            }
          }
        }
      }
    }

    const hasPriceMismatch = priceMismatches.length > 0;
    const needsReview = hasPriceMismatch || hasValidationErrors;
    const poStatus = needsReview ? "price_mismatch" : "processed";

    // ========== PREPARE SO DATA FROM CUSTOMER MASTER ==========
    const soData: any = {
      po_number: extractedData.po_number,
      vendor_name: extractedData.vendor_name,
      vendor_address: extractedData.vendor_address,
      order_date: extractedData.order_date,
      delivery_date: extractedData.delivery_date,
      total_amount: extractedData.total_amount,
      currency: extractedData.currency || "USD",
      status: poStatus,
      raw_text: extractedData.raw_text,
      original_filename: filename,
      email_subject: emailSubject,
      email_from: emailFrom,
      email_date: emailDate,
      price_mismatch_details: hasPriceMismatch ? priceMismatches : null,
      customer_match_log: customerMatchLog,
    };

    // Populate from Customer Master if matched (AUTHORITATIVE SOURCE)
    if (matchedCustomer) {
      soData.customer_master_id = matchedCustomer.id;
      soData.source_customer_master_id = matchedCustomer.id;
      soData.customer_name = matchedCustomer.customer_name;
      soData.gst_number = matchedCustomer.gst_number;
      soData.billing_address = matchedCustomer.billing_address;
      soData.shipping_address = matchedCustomer.shipping_address || matchedCustomer.billing_address;
      soData.payment_terms = matchedCustomer.payment_terms;
      soData.currency = matchedCustomer.currency || extractedData.currency || "INR";
      soData.tally_ledger_name = matchedCustomer.tally_ledger_name;
      soData.populated_at = new Date().toISOString();
      soData.population_source = "customer_master";
      // Use customer email for sending if available
      if (matchedCustomer.email && !emailFrom) {
        soData.email_from = matchedCustomer.email;
      }
      console.log("SO populated from Customer Master:", matchedCustomer.customer_name);
    } else {
      // Fallback to PO extracted data
      soData.customer_name = extractedData.customer_name;
      soData.customer_address = extractedData.customer_address;
      soData.population_source = "purchase_order";
      console.log("No customer match - using PO extracted data");
    }

    // Insert the purchase order
    const { data: poData, error: poError } = await supabase
      .from("purchase_orders")
      .insert(soData)
      .select()
      .single();

    if (poError) {
      console.error("Error inserting PO:", poError);
      throw poError;
    }

    console.log("Inserted PO:", poData.id, "with status:", poStatus);

    // Insert line items
    let insertedItems: any[] = [];
    if (extractedData.items && extractedData.items.length > 0) {
      const items = extractedData.items.map((item: any, index: number) => ({
        purchase_order_id: poData.id,
        item_number: item.item_number || index + 1,
        description: item.description,
        quantity: item.quantity,
        unit: item.unit || "pcs",
        unit_price: item.unit_price,
        total_price: item.total_price,
      }));

      const { data: itemsData, error: itemsError } = await supabase
        .from("purchase_order_items")
        .insert(items)
        .select();

      if (itemsError) {
        console.error("Error inserting items:", itemsError);
      } else {
        insertedItems = itemsData || [];
      }
    }

    // Only auto-send email if NO price mismatch and NO validation errors
    if (needsReview) {
      console.log("Review required - NOT sending Sales Order email.");
      if (hasPriceMismatch) {
        console.log("Price mismatches:", JSON.stringify(priceMismatches));
      }
      if (hasValidationErrors) {
        console.log("Validation errors:", validationErrors);
      }
    } else if (emailFrom || (matchedCustomer && matchedCustomer.email)) {
      // Auto-send Sales Order email
      const recipientEmail = emailFrom || matchedCustomer?.email;
      console.log("No issues - Auto-sending Sales Order email to:", recipientEmail);
      try {
        const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
        
        // Call the send-sales-order function
        const sendResponse = await fetch(
          `${SUPABASE_URL}/functions/v1/send-sales-order`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
            },
            body: JSON.stringify({
              orderId: poData.id,
              order: poData,
              items: insertedItems,
              recipientEmail: recipientEmail,
            }),
          }
        );

        if (sendResponse.ok) {
          console.log("Sales Order email sent successfully");
          // Update status to converted
          await supabase
            .from("purchase_orders")
            .update({ status: "converted" })
            .eq("id", poData.id);
        } else {
          const errorText = await sendResponse.text();
          console.error("Failed to send Sales Order email:", errorText);
        }
      } catch (emailError) {
        console.error("Error sending Sales Order email:", emailError);
        // Don't fail the whole process if email fails
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        purchaseOrderId: poData.id,
        extractedData,
        customerMatched: !!matchedCustomer,
        customerMatchLog,
        validationErrors: hasValidationErrors ? validationErrors : null,
        emailSent: !needsReview && !!(emailFrom || matchedCustomer?.email)
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error processing PO:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : "Unknown error" 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
