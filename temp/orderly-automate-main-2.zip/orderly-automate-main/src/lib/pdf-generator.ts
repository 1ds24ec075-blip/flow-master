import { type PurchaseOrder, type PurchaseOrderItem } from "./api";
import { formatDate, formatCurrency } from "./utils";

export async function generateSalesOrderPDF(
  order: PurchaseOrder,
  items: PurchaseOrderItem[]
): Promise<void> {
  // Generate HTML content for the sales order
  const html = generateSalesOrderHTML(order, items);

  // Create a new window for printing/saving as PDF
  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    throw new Error("Could not open print window. Please allow popups.");
  }

  printWindow.document.write(html);
  printWindow.document.close();

  // Wait for content to load then trigger print
  printWindow.onload = () => {
    printWindow.print();
  };
}

function generateSalesOrderHTML(
  order: PurchaseOrder,
  items: PurchaseOrderItem[]
): string {
  const soNumber = `SO-${order.po_number?.replace(/[^0-9]/g, "") || Date.now()}`;
  const subtotal = (order as any).subtotal || items.reduce((sum, item) => sum + (item.total_price || 0), 0);
  const taxAmount = (order as any).tax_amount || 0;
  const taxPercentage = (order as any).tax_percentage || (subtotal > 0 && taxAmount > 0 ? ((taxAmount / subtotal) * 100).toFixed(1) : 0);
  const discountAmount = (order as any).discount_amount || 0;
  const total = order.total_amount || (subtotal + taxAmount - discountAmount);

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sales Order - ${soNumber}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      font-size: 12px;
      color: #1a1a2e;
      background: white;
      padding: 40px;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 40px;
      padding-bottom: 20px;
      border-bottom: 2px solid #3b82f6;
    }
    .company-info h1 {
      font-size: 28px;
      color: #3b82f6;
      margin-bottom: 5px;
    }
    .company-info p {
      color: #64748b;
    }
    .document-info {
      text-align: right;
    }
    .document-info h2 {
      font-size: 24px;
      color: #1e293b;
      margin-bottom: 10px;
    }
    .document-info p {
      margin: 3px 0;
    }
    .document-info strong {
      color: #3b82f6;
    }
    .parties {
      display: flex;
      gap: 40px;
      margin-bottom: 30px;
    }
    .party {
      flex: 1;
      padding: 20px;
      background: #f8fafc;
      border-radius: 8px;
    }
    .party h3 {
      color: #3b82f6;
      margin-bottom: 10px;
      font-size: 14px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .party p {
      margin: 3px 0;
      line-height: 1.5;
    }
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }
    .items-table th {
      background: #3b82f6;
      color: white;
      padding: 12px 15px;
      text-align: left;
      font-weight: 600;
    }
    .items-table th:last-child,
    .items-table td:last-child {
      text-align: right;
    }
    .items-table th:nth-child(3),
    .items-table td:nth-child(3),
    .items-table th:nth-child(5),
    .items-table td:nth-child(5) {
      text-align: right;
    }
    .items-table td {
      padding: 12px 15px;
      border-bottom: 1px solid #e2e8f0;
    }
    .items-table tr:nth-child(even) {
      background: #f8fafc;
    }
    .totals {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 40px;
    }
    .totals-table {
      width: 300px;
    }
    .totals-table tr td {
      padding: 8px 15px;
    }
    .totals-table tr td:last-child {
      text-align: right;
      font-weight: 500;
    }
    .totals-table tr.total {
      font-size: 16px;
      font-weight: bold;
      background: #3b82f6;
      color: white;
    }
    .totals-table tr.total td {
      padding: 12px 15px;
    }
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #e2e8f0;
    }
    .footer h4 {
      color: #3b82f6;
      margin-bottom: 10px;
    }
    .footer p {
      color: #64748b;
      line-height: 1.6;
    }
    .reference {
      margin-top: 20px;
      padding: 15px;
      background: #fef3c7;
      border-radius: 8px;
      font-size: 11px;
    }
    .reference strong {
      color: #92400e;
    }
    @media print {
      body {
        padding: 20px;
      }
      .header {
        margin-bottom: 30px;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="company-info">
      <h1>Your Company</h1>
      <p>123 Business Street</p>
      <p>City, State 12345</p>
      <p>Phone: (555) 123-4567</p>
    </div>
    <div class="document-info">
      <h2>SALES ORDER</h2>
      <p><strong>SO Number:</strong> ${soNumber}</p>
      <p><strong>Date:</strong> ${formatDate(new Date().toISOString())}</p>
      <p><strong>PO Reference:</strong> ${order.po_number || "N/A"}</p>
    </div>
  </div>

  <div class="parties">
    <div class="party">
      <h3>Bill To / Ship To</h3>
      <p><strong>${order.customer_name || "Customer Name"}</strong></p>
      <p>${order.customer_address || "Customer Address"}</p>
    </div>
    <div class="party">
      <h3>Order Details</h3>
      <p><strong>Order Date:</strong> ${order.order_date ? formatDate(order.order_date) : "N/A"}</p>
      <p><strong>Delivery Date:</strong> ${order.delivery_date ? formatDate(order.delivery_date) : "TBD"}</p>
      <p><strong>Currency:</strong> ${order.currency || "USD"}</p>
    </div>
  </div>

  <table class="items-table">
    <thead>
      <tr>
        <th>#</th>
        <th>Description</th>
        <th>Qty</th>
        <th>Unit</th>
        <th>Unit Price</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>
      ${items
        .map(
          (item) => `
        <tr>
          <td>${item.item_number || ""}</td>
          <td>${item.description || ""}</td>
          <td>${item.quantity || 0}</td>
          <td>${item.unit || "pcs"}</td>
          <td>${formatCurrency(item.unit_price || 0, order.currency || "USD")}</td>
          <td>${formatCurrency(item.total_price || 0, order.currency || "USD")}</td>
        </tr>
      `
        )
        .join("")}
    </tbody>
  </table>

  <div class="totals">
    <table class="totals-table">
      <tr>
        <td>Subtotal:</td>
        <td>${formatCurrency(subtotal, order.currency || "USD")}</td>
      </tr>
      ${taxAmount > 0 ? `
      <tr>
        <td>Tax${taxPercentage ? ` (${taxPercentage}%)` : ''}:</td>
        <td>${formatCurrency(taxAmount, order.currency || "USD")}</td>
      </tr>
      ` : ''}
      ${discountAmount > 0 ? `
      <tr>
        <td>Discount:</td>
        <td>-${formatCurrency(discountAmount, order.currency || "USD")}</td>
      </tr>
      ` : ''}
      <tr class="total">
        <td>Total:</td>
        <td>${formatCurrency(total, order.currency || "USD")}</td>
      </tr>
    </table>
  </div>

  <div class="reference">
    <strong>Reference:</strong> This sales order was generated from Purchase Order ${order.po_number || "N/A"} 
    received from ${order.vendor_name || "vendor"} on ${order.order_date ? formatDate(order.order_date) : "N/A"}.
  </div>

  <div class="footer">
    <h4>Terms & Conditions</h4>
    <p>
      1. Payment terms: Net 30 days from invoice date.<br>
      2. Prices are valid for 30 days from the date of this order.<br>
      3. Delivery dates are estimates and subject to confirmation.
    </p>
  </div>
</body>
</html>
  `;
}
