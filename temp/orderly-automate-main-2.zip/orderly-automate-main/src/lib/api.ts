import { supabase } from "@/integrations/supabase/client";

export interface PurchaseOrder {
  id: string;
  po_number: string | null;
  vendor_name: string | null;
  vendor_address: string | null;
  customer_name: string | null;
  customer_address: string | null;
  order_date: string | null;
  delivery_date: string | null;
  total_amount: number | null;
  currency: string | null;
  status: string | null;
  raw_text: string | null;
  original_filename: string | null;
  email_subject: string | null;
  email_from: string | null;
  email_date: string | null;
  created_at: string;
  updated_at: string;
  price_mismatch_details?: any;
}

export interface PurchaseOrderItem {
  id: string;
  purchase_order_id: string;
  item_number: number | null;
  description: string | null;
  quantity: number | null;
  unit: string | null;
  unit_price: number | null;
  total_price: number | null;
  created_at: string;
}

export interface PriceItem {
  id: string;
  sku: string;
  product_name: string | null;
  unit_price: number;
  currency: string | null;
  created_at: string;
  updated_at: string;
}

export interface CustomerMaster {
  id: string;
  customer_name: string;
  gst_number: string | null;
  billing_address: string | null;
  shipping_address: string | null;
  payment_terms: string | null;
  currency: string | null;
  tally_ledger_name: string | null;
  is_active: boolean;
  email: string | null;
  phone: string | null;
  created_at: string;
  updated_at: string;
}

export async function fetchPurchaseOrders(): Promise<PurchaseOrder[]> {
  const { data, error } = await supabase
    .from("purchase_orders")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching purchase orders:", error);
    throw error;
  }

  return data || [];
}

export async function fetchPurchaseOrderWithItems(id: string): Promise<{
  order: PurchaseOrder;
  items: PurchaseOrderItem[];
}> {
  const [orderResult, itemsResult] = await Promise.all([
    supabase.from("purchase_orders").select("*").eq("id", id).single(),
    supabase
      .from("purchase_order_items")
      .select("*")
      .eq("purchase_order_id", id)
      .order("item_number", { ascending: true }),
  ]);

  if (orderResult.error) {
    console.error("Error fetching purchase order:", orderResult.error);
    throw orderResult.error;
  }

  return {
    order: orderResult.data,
    items: itemsResult.data || [],
  };
}

export async function deletePurchaseOrder(id: string): Promise<void> {
  const { error } = await supabase.from("purchase_orders").delete().eq("id", id);

  if (error) {
    console.error("Error deleting purchase order:", error);
    throw error;
  }
}

export async function updatePurchaseOrderStatus(
  id: string,
  status: string
): Promise<void> {
  const { error } = await supabase
    .from("purchase_orders")
    .update({ status })
    .eq("id", id);

  if (error) {
    console.error("Error updating purchase order:", error);
    throw error;
  }
}

// Price List API
export async function fetchPriceList(): Promise<PriceItem[]> {
  const { data, error } = await supabase
    .from("price_list")
    .select("*")
    .order("sku", { ascending: true });

  if (error) {
    console.error("Error fetching price list:", error);
    throw error;
  }

  return data || [];
}

export async function addPriceItem(item: Omit<PriceItem, "id" | "created_at" | "updated_at">): Promise<PriceItem> {
  const { data, error } = await supabase
    .from("price_list")
    .insert(item)
    .select()
    .single();

  if (error) {
    console.error("Error adding price item:", error);
    throw error;
  }

  return data;
}

export async function updatePriceItem(id: string, item: Partial<PriceItem>): Promise<void> {
  const { error } = await supabase
    .from("price_list")
    .update(item)
    .eq("id", id);

  if (error) {
    console.error("Error updating price item:", error);
    throw error;
  }
}

export async function deletePriceItem(id: string): Promise<void> {
  const { error } = await supabase.from("price_list").delete().eq("id", id);

  if (error) {
    console.error("Error deleting price item:", error);
    throw error;
  }
}

// Customer Master API
export async function fetchCustomerMaster(): Promise<CustomerMaster[]> {
  const { data, error } = await supabase
    .from("customer_master")
    .select("*")
    .order("customer_name", { ascending: true });

  if (error) {
    console.error("Error fetching customer master:", error);
    throw error;
  }

  return data || [];
}

export async function addCustomer(customer: Omit<CustomerMaster, "id" | "created_at" | "updated_at">): Promise<CustomerMaster> {
  const { data, error } = await supabase
    .from("customer_master")
    .insert(customer)
    .select()
    .single();

  if (error) {
    console.error("Error adding customer:", error);
    throw error;
  }

  return data;
}

export async function updateCustomer(id: string, customer: Partial<CustomerMaster>): Promise<void> {
  const { error } = await supabase
    .from("customer_master")
    .update(customer)
    .eq("id", id);

  if (error) {
    console.error("Error updating customer:", error);
    throw error;
  }
}

export async function deleteCustomer(id: string): Promise<void> {
  const { error } = await supabase.from("customer_master").delete().eq("id", id);

  if (error) {
    console.error("Error deleting customer:", error);
    throw error;
  }
}

export async function bulkImportCustomers(
  customers: Omit<CustomerMaster, "id" | "created_at" | "updated_at">[]
): Promise<{ success: number; failed: number; errors: string[] }> {
  const errors: string[] = [];
  let success = 0;
  let failed = 0;

  // Insert in batches of 50 for better performance
  const batchSize = 50;
  for (let i = 0; i < customers.length; i += batchSize) {
    const batch = customers.slice(i, i + batchSize);
    const { error } = await supabase.from("customer_master").insert(batch);

    if (error) {
      console.error("Error importing batch:", error);
      failed += batch.length;
      errors.push(`Batch ${Math.floor(i / batchSize) + 1}: ${error.message}`);
    } else {
      success += batch.length;
    }
  }

  return { success, failed, errors };
}

// Manual PO Creation
export interface ManualPOData {
  po_number: string;
  customer_name: string;
  customer_address: string;
  vendor_name: string;
  vendor_address: string;
  order_date: string | null;
  delivery_date: string | null;
  currency: string;
  email_from: string;
  total_amount: number;
}

export interface ManualPOItem {
  description: string;
  quantity: number;
  unit: string;
  unit_price: number;
}

export async function createManualPurchaseOrder(
  poData: ManualPOData,
  items: ManualPOItem[],
  sendSalesOrder: boolean = false
): Promise<string> {
  // Insert purchase order
  const { data: po, error: poError } = await supabase
    .from("purchase_orders")
    .insert({
      po_number: poData.po_number,
      customer_name: poData.customer_name,
      customer_address: poData.customer_address,
      vendor_name: poData.vendor_name,
      vendor_address: poData.vendor_address,
      order_date: poData.order_date,
      delivery_date: poData.delivery_date,
      currency: poData.currency,
      email_from: poData.email_from,
      total_amount: poData.total_amount,
      status: sendSalesOrder ? "pending" : "pending",
    })
    .select("id")
    .single();

  if (poError) {
    console.error("Error creating PO:", poError);
    throw poError;
  }

  // Insert items
  const itemsToInsert = items.map((item, index) => ({
    purchase_order_id: po.id,
    item_number: index + 1,
    description: item.description,
    quantity: item.quantity,
    unit: item.unit,
    unit_price: item.unit_price,
    total_price: item.quantity * item.unit_price,
  }));

  const { error: itemsError } = await supabase
    .from("purchase_order_items")
    .insert(itemsToInsert);

  if (itemsError) {
    console.error("Error creating PO items:", itemsError);
    throw itemsError;
  }

  // If sendSalesOrder is true, trigger the send-sales-order edge function
  if (sendSalesOrder && poData.email_from) {
    try {
      const { error: sendError } = await supabase.functions.invoke("send-sales-order", {
        body: { purchaseOrderId: po.id },
      });

      if (sendError) {
        console.error("Error sending sales order:", sendError);
        // Don't throw - PO was created successfully, just SO sending failed
      }
    } catch (err) {
      console.error("Failed to send sales order:", err);
    }
  }

  return po.id;
}
