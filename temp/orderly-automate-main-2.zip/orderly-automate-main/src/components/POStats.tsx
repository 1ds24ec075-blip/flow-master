import { type PurchaseOrder } from "@/lib/api";
import { FileText, CheckCircle, Clock, DollarSign } from "lucide-react";
import { Skeleton } from "./ui/skeleton";

interface POStatsProps {
  orders: PurchaseOrder[];
  isLoading: boolean;
}

export function POStats({ orders, isLoading }: POStatsProps) {
  const totalOrders = orders.length;
  const processedOrders = orders.filter((o) => o.status === "processed").length;
  const convertedOrders = orders.filter((o) => o.status === "converted").length;
  const totalValue = orders.reduce((sum, o) => sum + (o.total_amount || 0), 0);

  const stats = [
    {
      label: "Total Orders",
      value: totalOrders,
      icon: FileText,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      label: "Processed",
      value: processedOrders,
      icon: Clock,
      color: "text-warning",
      bgColor: "bg-warning/10",
    },
    {
      label: "Converted",
      value: convertedOrders,
      icon: CheckCircle,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      label: "Total Value",
      value: `$${totalValue.toLocaleString("en-US", { minimumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="rounded-lg border border-border bg-card p-6 shadow-card transition-shadow hover:shadow-elevated"
        >
          <div className="flex items-center gap-4">
            <div className={`rounded-lg p-3 ${stat.bgColor}`}>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
              {isLoading ? (
                <Skeleton className="mt-1 h-7 w-20" />
              ) : (
                <p className="text-2xl font-semibold text-foreground">
                  {stat.value}
                </p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
