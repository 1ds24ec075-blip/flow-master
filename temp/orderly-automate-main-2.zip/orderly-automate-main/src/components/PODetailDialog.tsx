import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  fetchPurchaseOrderWithItems,
  updatePurchaseOrderStatus,
  type PurchaseOrderItem,
} from "@/lib/api";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Skeleton } from "./ui/skeleton";
import { Download, CheckCircle, Mail, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatCurrency } from "@/lib/utils";
import { generateSalesOrderPDF } from "@/lib/pdf-generator";
import { supabase } from "@/integrations/supabase/client";

interface PODetailDialogProps {
  orderId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStatusChange: () => void;
}

export function PODetailDialog({
  orderId,
  open,
  onOpenChange,
  onStatusChange,
}: PODetailDialogProps) {
  const { toast } = useToast();
  const [isSending, setIsSending] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["purchase-order", orderId],
    queryFn: () => fetchPurchaseOrderWithItems(orderId!),
    enabled: !!orderId && open,
  });

  const handleDownload = async () => {
    if (!data) return;

    try {
      await generateSalesOrderPDF(data.order, data.items);
      
      // Update status to converted
      await updatePurchaseOrderStatus(data.order.id, "converted");
      onStatusChange();
      
      toast({
        title: "Sales Order Downloaded",
        description: "The sales order has been generated and downloaded.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate sales order.",
        variant: "destructive",
      });
    }
  };

  const handleSendEmail = async () => {
    if (!data) return;

    if (!data.order.email_from) {
      toast({
        title: "No Email Address",
        description: "This order doesn't have a sender email address to reply to.",
        variant: "destructive",
      });
      return;
    }

    setIsSending(true);
    try {
      const { data: response, error } = await supabase.functions.invoke("send-sales-order", {
        body: { orderId: data.order.id },
      });

      if (error) throw error;

      // Update status to converted
      await updatePurchaseOrderStatus(data.order.id, "converted");
      onStatusChange();

      toast({
        title: "Sales Order Sent",
        description: `Email sent to ${data.order.email_from}`,
      });
    } catch (error: any) {
      console.error("Error sending email:", error);
      toast({
        title: "Failed to Send",
        description: error.message || "Failed to send sales order email.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Purchase Order Details
            {data?.order.status === "converted" && (
              <Badge variant="outline" className="border-success text-success">
                <CheckCircle className="mr-1 h-3 w-3" />
                Converted
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-48 w-full" />
          </div>
        ) : data ? (
          <div className="space-y-6">
            {/* Order Info */}
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">
                    PO Number
                  </h3>
                  <p className="text-lg font-semibold">
                    {data.order.po_number || "—"}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Vendor
                  </h3>
                  <p className="font-medium">{data.order.vendor_name || "—"}</p>
                  <p className="text-sm text-muted-foreground">
                    {data.order.vendor_address || ""}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Order Date
                  </h3>
                  <p>
                    {data.order.order_date
                      ? formatDate(data.order.order_date)
                      : "—"}
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Total Amount
                  </h3>
                  <p className="text-lg font-semibold">
                    {data.order.total_amount
                      ? formatCurrency(
                          data.order.total_amount,
                          data.order.currency || "USD"
                        )
                      : "—"}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Customer
                  </h3>
                  <p className="font-medium">
                    {data.order.customer_name || "—"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {data.order.customer_address || ""}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Delivery Date
                  </h3>
                  <p>
                    {data.order.delivery_date
                      ? formatDate(data.order.delivery_date)
                      : "—"}
                  </p>
                </div>
              </div>
            </div>

            {/* Line Items */}
            <div>
              <h3 className="mb-3 font-semibold">Line Items</h3>
              {data.items.length > 0 ? (
                <div className="rounded-lg border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-16">#</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead className="text-right">Qty</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead className="text-right">Unit Price</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>{item.item_number}</TableCell>
                          <TableCell>{item.description || "—"}</TableCell>
                          <TableCell className="text-right">
                            {item.quantity}
                          </TableCell>
                          <TableCell>{item.unit || "pcs"}</TableCell>
                          <TableCell className="text-right">
                            {item.unit_price
                              ? formatCurrency(
                                  item.unit_price,
                                  data.order.currency || "USD"
                                )
                              : "—"}
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {item.total_price
                              ? formatCurrency(
                                  item.total_price,
                                  data.order.currency || "USD"
                                )
                              : "—"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No line items found.
                </p>
              )}
            </div>

            {/* Email Info */}
            {(data.order.email_subject || data.order.email_from) && (
              <div className="rounded-lg bg-muted/50 p-4">
                <h3 className="mb-2 text-sm font-medium">Email Source</h3>
                <p className="text-sm">
                  <span className="text-muted-foreground">Subject:</span>{" "}
                  {data.order.email_subject}
                </p>
                <p className="text-sm">
                  <span className="text-muted-foreground">From:</span>{" "}
                  {data.order.email_from}
                </p>
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t border-border">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Close
              </Button>
              <Button variant="outline" onClick={handleDownload}>
                <Download className="mr-2 h-4 w-4" />
                Download PDF
              </Button>
              <Button onClick={handleSendEmail} disabled={isSending || !data.order.email_from}>
                {isSending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Mail className="mr-2 h-4 w-4" />
                )}
                Send to {data.order.email_from ? data.order.email_from.split("@")[0] : "Email"}
              </Button>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
