import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface AppScriptDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AppScriptDialog({ open, onOpenChange }: AppScriptDialogProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  const appScript = `// Google Apps Script - Purchase Order Processor
// This script searches Gmail for PO emails and sends PDFs to your Lovable app

const SUPABASE_URL = "${supabaseUrl}";
const SUPABASE_KEY = "${supabaseKey}";
const EDGE_FUNCTION_URL = SUPABASE_URL + "/functions/v1/process-po";

// Set up a time-based trigger to run every hour
function createTrigger() {
  // Delete existing triggers first
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(trigger => {
    if (trigger.getHandlerFunction() === 'processNewPOEmails') {
      ScriptApp.deleteTrigger(trigger);
    }
  });
  
  // Create new hourly trigger
  ScriptApp.newTrigger('processNewPOEmails')
    .timeBased()
    .everyHours(1)
    .create();
    
  Logger.log('Trigger created to run every hour');
}

// Main function to process PO emails
function processNewPOEmails() {
  // Search for unread emails with "po" or "purchase order" in subject
  const searchQuery = 'is:unread (subject:po OR subject:"purchase order") has:attachment';
  const threads = GmailApp.search(searchQuery, 0, 10); // Process up to 10 at a time
  
  Logger.log('Found ' + threads.length + ' threads to process');
  
  threads.forEach(thread => {
    const messages = thread.getMessages();
    
    messages.forEach(message => {
      if (message.isUnread()) {
        processMessage(message);
        message.markRead(); // Mark as read after processing
      }
    });
  });
}

// Process a single email message
function processMessage(message) {
  const attachments = message.getAttachments();
  const subject = message.getSubject();
  const from = message.getFrom();
  const date = message.getDate().toISOString();
  
  Logger.log('Processing: ' + subject + ' from ' + from);
  
  attachments.forEach(attachment => {
    const filename = attachment.getName().toLowerCase();
    
    // Only process PDF files
    if (filename.endsWith('.pdf')) {
      Logger.log('Found PDF: ' + filename);
      
      // Convert to base64
      const blob = attachment.copyBlob();
      const base64 = Utilities.base64Encode(blob.getBytes());
      
      // Send to edge function
      sendToProcessor(base64, attachment.getName(), subject, from, date);
    }
  });
}

// Send PDF to the Lovable app for processing
function sendToProcessor(pdfBase64, filename, emailSubject, emailFrom, emailDate) {
  const payload = {
    pdfBase64: pdfBase64,
    filename: filename,
    emailSubject: emailSubject,
    emailFrom: emailFrom,
    emailDate: emailDate
  };
  
  const options = {
    method: 'POST',
    contentType: 'application/json',
    headers: {
      'Authorization': 'Bearer ' + SUPABASE_KEY
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };
  
  try {
    const response = UrlFetchApp.fetch(EDGE_FUNCTION_URL, options);
    const responseCode = response.getResponseCode();
    const responseBody = response.getContentText();
    
    if (responseCode === 200) {
      Logger.log('Successfully processed: ' + filename);
      Logger.log('Response: ' + responseBody);
    } else {
      Logger.log('Error processing ' + filename + ': ' + responseCode + ' - ' + responseBody);
    }
  } catch (error) {
    Logger.log('Error: ' + error.toString());
  }
}

// Manual test function
function testProcessing() {
  // For testing - manually trigger processing
  processNewPOEmails();
}
`;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(appScript);
    setCopied(true);
    toast({
      title: "Copied!",
      description: "Apps Script code copied to clipboard.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Google Apps Script Setup</DialogTitle>
          <DialogDescription>
            Copy this script to your Google Apps Script project to automatically
            process PO emails from Gmail.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-lg bg-muted p-4">
            <h3 className="font-medium mb-2">Setup Instructions:</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
              <li>
                Go to{" "}
                <a
                  href="https://script.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary underline"
                >
                  script.google.com
                </a>
              </li>
              <li>Create a new project</li>
              <li>Paste the code below and save</li>
              <li>
                Run <code className="bg-background px-1 rounded">createTrigger()</code>{" "}
                to set up hourly processing
              </li>
              <li>Authorize the script when prompted</li>
            </ol>
          </div>

          <div className="relative">
            <Button
              variant="outline"
              size="sm"
              className="absolute right-2 top-2 z-10"
              onClick={handleCopy}
            >
              {copied ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </>
              )}
            </Button>
            <pre className="rounded-lg bg-foreground/5 p-4 text-xs overflow-auto max-h-96 font-mono">
              <code>{appScript}</code>
            </pre>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
