import { useState } from "react";
import { format } from "date-fns";
import { Eye, Check, X, AlertTriangle, Loader2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { type PurchaseOrder, updatePurchaseOrderStatus, deletePurchaseOrder } from "@/lib/api";

interface ReviewTableProps {
  orders: PurchaseOrder[];
  isLoading: boolean;
  onRefresh: () => void;
}

interface PriceMismatch {
  sku: string;
  product_name: string;
  item_description: string;
  expected_price: number;
  actual_price: number;
  variance_percent: string;
  item_number: number;
}

const ReviewTable = ({ orders, isLoading, onRefresh }: ReviewTableProps) => {
  const [selectedMismatches, setSelectedMismatches] = useState<PriceMismatch[] | null>(null);
  const [selectedPONumber, setSelectedPONumber] = useState<string>("");
  const [approveOrder, setApproveOrder] = useState<PurchaseOrder | null>(null);
  const [isApproving, setIsApproving] = useState(false);

  const handleApproveClick = (order: PurchaseOrder) => {
    setApproveOrder(order);
  };

  const handleConfirmApprove = async () => {
    if (!approveOrder) return;
    
    setIsApproving(true);
    try {
      // First update status to processed
      await updatePurchaseOrderStatus(approveOrder.id, "processed");
      
      // Then trigger SO email if we have sender email
      if (approveOrder.email_from) {
        const { error } = await supabase.functions.invoke("send-sales-order", {
          body: {
            orderId: approveOrder.id,
            recipientEmail: approveOrder.email_from,
          },
        });
        
        if (error) {
          console.error("Failed to send SO email:", error);
          toast.warning(`PO ${approveOrder.po_number} approved but email failed to send`);
        } else {
          // Update status to converted
          await updatePurchaseOrderStatus(approveOrder.id, "converted");
          toast.success(`PO ${approveOrder.po_number} approved and Sales Order sent!`);
        }
      } else {
        toast.success(`PO ${approveOrder.po_number} approved (no email to send)`);
      }
      
      setApproveOrder(null);
      onRefresh();
    } catch (error) {
      console.error("Approve error:", error);
      toast.error("Failed to approve order");
    } finally {
      setIsApproving(false);
    }
  };

  const handleReject = async (id: string, poNumber: string | null) => {
    try {
      await deletePurchaseOrder(id);
      toast.success(`PO ${poNumber || id} rejected and removed`);
      onRefresh();
    } catch (error) {
      toast.error("Failed to reject order");
    }
  };

  const viewMismatches = (order: PurchaseOrder) => {
    const mismatches = (order as any).price_mismatch_details as PriceMismatch[] | null;
    setSelectedMismatches(mismatches || []);
    setSelectedPONumber(order.po_number || order.id);
  };

  const formatCurrency = (amount: number | null, currency: string | null) => {
    if (amount === null) return "-";
    const symbol = currency === "INR" ? "₹" : currency === "EUR" ? "€" : "$";
    return `${symbol}${amount.toLocaleString()}`;
  };

  if (isLoading) {
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>PO Number</TableHead>
              <TableHead>Vendor</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Mismatches</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {[1, 2, 3].map((i) => (
              <TableRow key={i}>
                {[1, 2, 3, 4, 5, 6].map((j) => (
                  <TableCell key={j}>
                    <Skeleton className="h-4 w-20" />
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="rounded-md border p-12 text-center">
        <Check className="h-12 w-12 text-green-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">
          All Clear!
        </h3>
        <p className="text-muted-foreground">
          No purchase orders with price discrepancies.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>PO Number</TableHead>
              <TableHead>Vendor</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Mismatches</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => {
              const mismatches = (order as any).price_mismatch_details as PriceMismatch[] | null;
              return (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">
                    {order.po_number || "-"}
                  </TableCell>
                  <TableCell>{order.vendor_name || "-"}</TableCell>
                  <TableCell>
                    {order.order_date
                      ? format(new Date(order.order_date), "MMM dd, yyyy")
                      : "-"}
                  </TableCell>
                  <TableCell>
                    {formatCurrency(order.total_amount, order.currency)}
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="destructive" 
                      className="cursor-pointer"
                      onClick={() => viewMismatches(order)}
                    >
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      {mismatches?.length || 0} items
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => viewMismatches(order)}
                        title="View mismatches"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-green-600 hover:text-green-700 hover:bg-green-50"
                        onClick={() => handleApproveClick(order)}
                        title="Approve"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            title="Reject"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Reject Purchase Order?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete PO {order.po_number || order.id}. 
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleReject(order.id, order.po_number)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Reject
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Mismatch Details Dialog */}
      <Dialog open={!!selectedMismatches} onOpenChange={() => setSelectedMismatches(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Price Mismatches - PO {selectedPONumber}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>SKU</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Expected</TableHead>
                  <TableHead className="text-right">PO Price</TableHead>
                  <TableHead className="text-right">Variance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedMismatches?.map((mismatch, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-mono text-sm">
                      {mismatch.sku}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {mismatch.product_name || mismatch.item_description}
                    </TableCell>
                    <TableCell className="text-right text-green-600 font-medium">
                      ₹{mismatch.expected_price.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right text-red-600 font-medium">
                      ₹{mismatch.actual_price.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="destructive">
                        {mismatch.variance_percent}%
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Approve Confirmation Dialog */}
      <Dialog open={!!approveOrder} onOpenChange={() => !isApproving && setApproveOrder(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Confirm Approval - PO {approveOrder?.po_number}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-2">
            <p className="text-muted-foreground mb-4">
              The following items have price differences. Are you sure you want to approve and send the Sales Order?
            </p>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Our Price</TableHead>
                  <TableHead className="text-right">PO Price</TableHead>
                  <TableHead className="text-right">Variance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {((approveOrder as any)?.price_mismatch_details as PriceMismatch[] | null)?.map((mismatch, index) => (
                  <TableRow key={index}>
                    <TableCell className="max-w-[200px] truncate">
                      {mismatch.product_name || mismatch.item_description}
                    </TableCell>
                    <TableCell className="text-right text-green-600 font-medium">
                      ₹{mismatch.expected_price.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right text-red-600 font-medium">
                      ₹{mismatch.actual_price.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="destructive">
                        {mismatch.variance_percent}%
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setApproveOrder(null)} disabled={isApproving}>
              Cancel
            </Button>
            <Button 
              onClick={handleConfirmApprove} 
              disabled={isApproving}
              className="bg-green-600 hover:bg-green-700"
            >
              {isApproving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Confirm & Send SO
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ReviewTable;
