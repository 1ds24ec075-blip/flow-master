import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Checkbox } from "./ui/checkbox";
import { Plus, Trash2, Upload, FileText, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { createManualPurchaseOrder } from "@/lib/api";
import { supabase } from "@/integrations/supabase/client";

interface POItem {
  description: string;
  quantity: number;
  unit: string;
  unit_price: number;
}

interface AddPODialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function AddPODialog({ open, onOpenChange, onSuccess }: AddPODialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [sendSalesOrder, setSendSalesOrder] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    po_number: "",
    customer_name: "",
    customer_address: "",
    vendor_name: "",
    vendor_address: "",
    order_date: "",
    delivery_date: "",
    currency: "INR",
    email_from: "",
  });

  const [items, setItems] = useState<POItem[]>([
    { description: "", quantity: 1, unit: "PCS", unit_price: 0 }
  ]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleItemChange = (index: number, field: keyof POItem, value: string | number) => {
    setItems(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  const addItem = () => {
    setItems(prev => [...prev, { description: "", quantity: 1, unit: "PCS", unit_price: 0 }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(prev => prev.filter((_, i) => i !== index));
    }
  };

  const calculateTotal = () => {
    return items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
  };

  const resetForm = () => {
    setFormData({
      po_number: "",
      customer_name: "",
      customer_address: "",
      vendor_name: "",
      vendor_address: "",
      order_date: "",
      delivery_date: "",
      currency: "INR",
      email_from: "",
    });
    setItems([{ description: "", quantity: 1, unit: "PCS", unit_price: 0 }]);
    setUploadedFile(null);
    setSendSalesOrder(false);
  };

  const handleFileSelect = async (file: File) => {
    if (!file.type.includes("pdf")) {
      toast({
        title: "Invalid File",
        description: "Please upload a PDF file.",
        variant: "destructive",
      });
      return;
    }

    setUploadedFile(file);
    setIsExtracting(true);

    try {
      // Convert file to base64
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1]); // Remove data:application/pdf;base64, prefix
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Call the process-po edge function with extractOnly flag
      const { data, error } = await supabase.functions.invoke("process-po", {
        body: {
          pdfBase64: base64,
          filename: file.name,
          extractOnly: true, // Flag to indicate we only want extraction, not full processing
        },
      });

      if (error) throw error;

      if (data?.extractedData) {
        const extracted = data.extractedData;
        
        // Populate form with extracted data
        setFormData(prev => ({
          ...prev,
          po_number: extracted.po_number || prev.po_number,
          customer_name: extracted.customer_name || prev.customer_name,
          customer_address: extracted.customer_address || prev.customer_address,
          vendor_name: extracted.vendor_name || prev.vendor_name,
          vendor_address: extracted.vendor_address || prev.vendor_address,
          order_date: extracted.order_date || prev.order_date,
          delivery_date: extracted.delivery_date || prev.delivery_date,
          currency: extracted.currency || prev.currency,
          email_from: extracted.email_from || prev.email_from,
        }));

        // Populate items if available
        if (extracted.items && extracted.items.length > 0) {
          setItems(extracted.items.map((item: any) => ({
            description: item.description || item.sku || "",
            quantity: item.quantity || 1,
            unit: item.unit || "PCS",
            unit_price: item.unit_price || 0,
          })));
        }

        toast({
          title: "PDF Extracted",
          description: "Form populated with extracted data. Please review and edit as needed.",
        });
      }
    } catch (error) {
      console.error("Error extracting PDF:", error);
      toast({
        title: "Extraction Failed",
        description: "Could not extract data from PDF. Please enter details manually.",
        variant: "destructive",
      });
    } finally {
      setIsExtracting(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleSubmit = async () => {
    if (!formData.po_number || !formData.customer_name) {
      toast({
        title: "Validation Error",
        description: "PO Number and Customer Name are required.",
        variant: "destructive",
      });
      return;
    }

    if (items.some(item => !item.description)) {
      toast({
        title: "Validation Error",
        description: "All items must have a description.",
        variant: "destructive",
      });
      return;
    }

    if (sendSalesOrder && !formData.email_from) {
      toast({
        title: "Validation Error",
        description: "Customer email is required to send Sales Order.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const poId = await createManualPurchaseOrder({
        ...formData,
        order_date: formData.order_date || null,
        delivery_date: formData.delivery_date || null,
        total_amount: calculateTotal(),
      }, items, sendSalesOrder);

      toast({
        title: "Success",
        description: sendSalesOrder 
          ? "Purchase order created and Sales Order sent." 
          : "Purchase order created successfully.",
      });
      
      resetForm();
      onOpenChange(false);
      onSuccess();
    } catch (error) {
      console.error("Error creating PO:", error);
      toast({
        title: "Error",
        description: "Failed to create purchase order.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Purchase Order</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* PDF Upload Section */}
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              isExtracting ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50"
            }`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
            />
            
            {isExtracting ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">Extracting PO details...</p>
              </div>
            ) : uploadedFile ? (
              <div className="flex flex-col items-center gap-2">
                <FileText className="h-8 w-8 text-primary" />
                <p className="text-sm font-medium">{uploadedFile.name}</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                >
                  Upload Different PDF
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Drag & drop a PDF, or{" "}
                  <button
                    type="button"
                    className="text-primary underline"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    browse
                  </button>
                </p>
                <p className="text-xs text-muted-foreground">
                  Upload a PO PDF to auto-fill the form
                </p>
              </div>
            )}
          </div>

          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="po_number">PO Number *</Label>
              <Input
                id="po_number"
                value={formData.po_number}
                onChange={(e) => handleInputChange("po_number", e.target.value)}
                placeholder="PO-001"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={formData.currency} onValueChange={(v) => handleInputChange("currency", v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="INR">INR</SelectItem>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Customer Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customer_name">Customer Name *</Label>
              <Input
                id="customer_name"
                value={formData.customer_name}
                onChange={(e) => handleInputChange("customer_name", e.target.value)}
                placeholder="Customer Company Ltd"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email_from">Customer Email</Label>
              <Input
                id="email_from"
                type="email"
                value={formData.email_from}
                onChange={(e) => handleInputChange("email_from", e.target.value)}
                placeholder="customer@example.com"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="customer_address">Customer Address</Label>
            <Textarea
              id="customer_address"
              value={formData.customer_address}
              onChange={(e) => handleInputChange("customer_address", e.target.value)}
              placeholder="Full address"
              rows={2}
            />
          </div>

          {/* Vendor Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vendor_name">Vendor Name</Label>
              <Input
                id="vendor_name"
                value={formData.vendor_name}
                onChange={(e) => handleInputChange("vendor_name", e.target.value)}
                placeholder="Your Company"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vendor_address">Vendor Address</Label>
              <Input
                id="vendor_address"
                value={formData.vendor_address}
                onChange={(e) => handleInputChange("vendor_address", e.target.value)}
                placeholder="Vendor address"
              />
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="order_date">Order Date</Label>
              <Input
                id="order_date"
                type="date"
                value={formData.order_date}
                onChange={(e) => handleInputChange("order_date", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="delivery_date">Delivery Date</Label>
              <Input
                id="delivery_date"
                type="date"
                value={formData.delivery_date}
                onChange={(e) => handleInputChange("delivery_date", e.target.value)}
              />
            </div>
          </div>

          {/* Line Items */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Line Items</Label>
              <Button type="button" variant="outline" size="sm" onClick={addItem}>
                <Plus className="mr-1 h-4 w-4" />
                Add Item
              </Button>
            </div>

            <div className="space-y-2">
              {items.map((item, index) => (
                <div key={index} className="grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-5">
                    {index === 0 && <Label className="text-xs text-muted-foreground">Description</Label>}
                    <Input
                      value={item.description}
                      onChange={(e) => handleItemChange(index, "description", e.target.value)}
                      placeholder="Item description / SKU"
                    />
                  </div>
                  <div className="col-span-2">
                    {index === 0 && <Label className="text-xs text-muted-foreground">Qty</Label>}
                    <Input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => handleItemChange(index, "quantity", parseFloat(e.target.value) || 0)}
                      min={0}
                    />
                  </div>
                  <div className="col-span-2">
                    {index === 0 && <Label className="text-xs text-muted-foreground">Unit</Label>}
                    <Input
                      value={item.unit}
                      onChange={(e) => handleItemChange(index, "unit", e.target.value)}
                      placeholder="PCS"
                    />
                  </div>
                  <div className="col-span-2">
                    {index === 0 && <Label className="text-xs text-muted-foreground">Price</Label>}
                    <Input
                      type="number"
                      value={item.unit_price}
                      onChange={(e) => handleItemChange(index, "unit_price", parseFloat(e.target.value) || 0)}
                      min={0}
                      step="0.01"
                    />
                  </div>
                  <div className="col-span-1">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeItem(index)}
                      disabled={items.length === 1}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2 border-t">
              <div className="text-sm font-medium">
                Total: {formData.currency} {calculateTotal().toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          {/* Send Sales Order Option */}
          <div className="flex items-center space-x-2 p-4 bg-muted/50 rounded-lg">
            <Checkbox
              id="send-so"
              checked={sendSalesOrder}
              onCheckedChange={(checked) => setSendSalesOrder(checked === true)}
            />
            <div className="grid gap-1.5 leading-none">
              <label
                htmlFor="send-so"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                Send Sales Order after saving
              </label>
              <p className="text-xs text-muted-foreground">
                Automatically generate and email the Sales Order to the customer
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || isExtracting}>
            {isSubmitting ? "Creating..." : sendSalesOrder ? "Create & Send SO" : "Create PO"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
