import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { fetchPurchaseOrders, type PurchaseOrder } from "@/lib/api";
import { POTable } from "./POTable";
import { POStats } from "./POStats";
import { FileText, RefreshCw, Code, AlertTriangle, ListOrdered, Building2, Plus } from "lucide-react";
import { Button } from "./ui/button";
import { useToast } from "@/hooks/use-toast";
import { AppScriptDialog } from "./AppScriptDialog";
import { AddPODialog } from "./AddPODialog";
import { Badge } from "./ui/badge";

export function PODashboard() {
  const { toast } = useToast();
  const [showScript, setShowScript] = useState(false);
  const [showAddPO, setShowAddPO] = useState(false);

  const {
    data: orders = [],
    isLoading,
    refetch,
    isRefetching,
  } = useQuery({
    queryKey: ["purchase-orders"],
    queryFn: fetchPurchaseOrders,
    refetchInterval: 30000, // Auto-refresh every 30 seconds
  });

  // Filter out price_mismatch orders from main dashboard
  const mainOrders = orders.filter((o) => o.status !== "price_mismatch");
  const mismatchCount = orders.filter((o) => o.status === "price_mismatch").length;

  const handleRefresh = async () => {
    await refetch();
    toast({
      title: "Refreshed",
      description: "Purchase orders have been refreshed.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">
                  PO Processor
                </h1>
                <p className="text-sm text-muted-foreground">
                  Purchase Order to Sales Order Converter
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button size="sm" onClick={() => setShowAddPO(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add PO
              </Button>
              <Link to="/customer-master">
                <Button variant="outline" size="sm">
                  <Building2 className="mr-2 h-4 w-4" />
                  Customers
                </Button>
              </Link>
              <Link to="/price-list">
                <Button variant="outline" size="sm">
                  <ListOrdered className="mr-2 h-4 w-4" />
                  Price List
                </Button>
              </Link>
              <Link to="/review">
                <Button 
                  variant={mismatchCount > 0 ? "default" : "outline"} 
                  size="sm"
                  className={mismatchCount > 0 ? "bg-orange-500 hover:bg-orange-600" : ""}
                >
                  <AlertTriangle className="mr-2 h-4 w-4" />
                  Review
                  {mismatchCount > 0 && (
                    <Badge variant="secondary" className="ml-2 bg-white/20 text-white">
                      {mismatchCount}
                    </Badge>
                  )}
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowScript(true)}
              >
                <Code className="mr-2 h-4 w-4" />
                Apps Script
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isRefetching}
              >
                <RefreshCw
                  className={`mr-2 h-4 w-4 ${isRefetching ? "animate-spin" : ""}`}
                />
                Refresh
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <div className="space-y-8">
          {/* Stats Cards */}
          <POStats orders={mainOrders} isLoading={isLoading} />

          {/* Orders Table */}
          <div className="rounded-lg border border-border bg-card shadow-card">
            <div className="border-b border-border px-6 py-4">
              <h2 className="text-lg font-semibold text-foreground">
                Purchase Orders
              </h2>
              <p className="text-sm text-muted-foreground">
                View and manage all processed purchase orders
              </p>
            </div>
            <POTable orders={mainOrders} isLoading={isLoading} onRefresh={refetch} />
          </div>
        </div>
      </main>

      {/* Apps Script Dialog */}
      <AppScriptDialog open={showScript} onOpenChange={setShowScript} />
      
      {/* Add PO Dialog */}
      <AddPODialog open={showAddPO} onOpenChange={setShowAddPO} onSuccess={() => refetch()} />
    </div>
  );
}
