import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Plus, Pencil, Trash2, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { fetchPriceList, addPriceItem, updatePriceItem, deletePriceItem, type PriceItem } from "@/lib/api";

const PriceList = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PriceItem | null>(null);
  const [formData, setFormData] = useState({
    sku: "",
    product_name: "",
    unit_price: "",
    currency: "INR",
  });

  const { data: priceList = [], isLoading, refetch } = useQuery({
    queryKey: ["priceList"],
    queryFn: fetchPriceList,
  });

  const handleRefresh = async () => {
    await refetch();
    toast.success("Price list refreshed");
  };

  const openAddDialog = () => {
    setEditingItem(null);
    setFormData({ sku: "", product_name: "", unit_price: "", currency: "INR" });
    setIsDialogOpen(true);
  };

  const openEditDialog = (item: PriceItem) => {
    setEditingItem(item);
    setFormData({
      sku: item.sku,
      product_name: item.product_name || "",
      unit_price: String(item.unit_price),
      currency: item.currency || "INR",
    });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.sku || !formData.unit_price) {
      toast.error("SKU and Unit Price are required");
      return;
    }

    try {
      const data = {
        sku: formData.sku.toUpperCase(),
        product_name: formData.product_name || null,
        unit_price: parseFloat(formData.unit_price),
        currency: formData.currency,
      };

      if (editingItem) {
        await updatePriceItem(editingItem.id, data);
        toast.success("Price item updated");
      } else {
        await addPriceItem(data);
        toast.success("Price item added");
      }

      setIsDialogOpen(false);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to save price item");
    }
  };

  const handleDelete = async (id: string, sku: string) => {
    try {
      await deletePriceItem(id);
      toast.success(`SKU ${sku} deleted`);
      refetch();
    } catch (error) {
      toast.error("Failed to delete price item");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                Master Price List
              </h1>
              <p className="text-muted-foreground text-sm mt-1">
                Manage product SKUs and their standard prices
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            <Button size="sm" onClick={openAddDialog} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Product
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>SKU / Product Code</TableHead>
                <TableHead>Product Name</TableHead>
                <TableHead className="text-right">Unit Price</TableHead>
                <TableHead>Currency</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [1, 2, 3].map((i) => (
                  <TableRow key={i}>
                    {[1, 2, 3, 4, 5].map((j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-4 w-20" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : priceList.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12">
                    <p className="text-muted-foreground">No products in price list yet.</p>
                    <Button variant="link" onClick={openAddDialog}>
                      Add your first product
                    </Button>
                  </TableCell>
                </TableRow>
              ) : (
                priceList.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-mono font-medium">
                      {item.sku}
                    </TableCell>
                    <TableCell>{item.product_name || "-"}</TableCell>
                    <TableCell className="text-right font-medium">
                      {item.unit_price.toLocaleString()}
                    </TableCell>
                    <TableCell>{item.currency || "INR"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditDialog(item)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete {item.sku}?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will remove the product from your price list.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(item.id, item.sku)}
                                className="bg-destructive text-destructive-foreground"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Add/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingItem ? "Edit Product" : "Add Product"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="sku">SKU / Product Code *</Label>
                <Input
                  id="sku"
                  value={formData.sku}
                  onChange={(e) =>
                    setFormData({ ...formData, sku: e.target.value })
                  }
                  placeholder="e.g., PROD-001"
                  disabled={!!editingItem}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="product_name">Product Name</Label>
                <Input
                  id="product_name"
                  value={formData.product_name}
                  onChange={(e) =>
                    setFormData({ ...formData, product_name: e.target.value })
                  }
                  placeholder="e.g., Widget Pro"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="unit_price">Unit Price *</Label>
                <Input
                  id="unit_price"
                  type="number"
                  step="0.01"
                  value={formData.unit_price}
                  onChange={(e) =>
                    setFormData({ ...formData, unit_price: e.target.value })
                  }
                  placeholder="0.00"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave}>
                {editingItem ? "Update" : "Add"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default PriceList;
