import { useQuery } from "@tanstack/react-query";
import { fetchPurchaseOrders, type PurchaseOrder } from "@/lib/api";
import { RefreshCw, AlertTriangle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import ReviewTable from "@/components/ReviewTable";

const Review = () => {
  const {
    data: allOrders = [],
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["purchaseOrders"],
    queryFn: fetchPurchaseOrders,
    refetchInterval: 30000,
  });

  // Filter only price mismatch orders
  const mismatchOrders = allOrders.filter(
    (order) => order.status === "price_mismatch"
  );

  const handleRefresh = async () => {
    await refetch();
    toast.success("Data refreshed");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-6 w-6 text-orange-500" />
                <h1 className="text-2xl font-bold text-foreground">
                  Price Review Dashboard
                </h1>
              </div>
              <p className="text-muted-foreground text-sm mt-1">
                Purchase orders with price discrepancies requiring manual review
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Stats Card */}
        <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-8 w-8 text-orange-500" />
            <div>
              <p className="text-2xl font-bold text-orange-700 dark:text-orange-400">
                {mismatchOrders.length}
              </p>
              <p className="text-sm text-orange-600 dark:text-orange-300">
                Orders pending price review
              </p>
            </div>
          </div>
        </div>

        {/* Table */}
        <ReviewTable
          orders={mismatchOrders}
          isLoading={isLoading}
          onRefresh={handleRefresh}
        />
      </div>
    </div>
  );
};

export default Review;
