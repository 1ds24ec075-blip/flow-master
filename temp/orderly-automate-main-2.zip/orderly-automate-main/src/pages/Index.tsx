import { PODashboard } from "@/components/PODashboard";

const Index = () => {
  return <PODashboard />;
};

export default Index;
